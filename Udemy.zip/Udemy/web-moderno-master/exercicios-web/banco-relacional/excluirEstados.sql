delete from estados
where sigla = 'MN'

select * from estados

delete from estados
where id >= 1000