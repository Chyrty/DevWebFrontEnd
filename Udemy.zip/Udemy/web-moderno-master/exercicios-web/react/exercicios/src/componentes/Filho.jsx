import React from 'react'

export default props => <li>{props.nome} {props.sobrenome}</li>